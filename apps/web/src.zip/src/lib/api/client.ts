import {
  SignupRequestDto,
  LoginRequestDto,
  UserView,
  GetProjectsQueryDto,
  PaginatedProjectsListView,
  CreateProjectDto,
  ProjectView,
  TaskView,
  CreateTaskDto,
  FindTasksQuery,
  PaginationResult,
  ProjectDetailView,
  UpdateProjectDto,
  ProjectMembersView,
  AddProjectMemberDto,
  ProjectMemberView,
  UpdateProjectMemberRoleDto,
} from "@repo/types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL;

type SessionExpiredHandler = () => void;
let sessionExpiredHandler: SessionExpiredHandler | null = null;

export function setSessionExpiredHandler(handler: SessionExpiredHandler) {
  sessionExpiredHandler = handler;
}

let refreshPromise: Promise<boolean> | null = null;

async function doRefresh(): Promise<boolean> {
  if (refreshPromise) return refreshPromise;
  refreshPromise = (async () => {
    try {
      const res = await fetch(`${API_BASE}/api/auth/refresh`, {
        method: "POST",
        credentials: "include",
      });
      return res.ok;
    } finally {
      refreshPromise = null;
    }
  })();
  return refreshPromise;
}

function isRefreshUrl(url: string): boolean {
  return url.includes("/auth/refresh");
}

export async function fetchWithAuth(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  const url =
    typeof input === "string"
      ? input
      : input instanceof Request
        ? input.url
        : String(input);

  let res = await fetch(input, {
    ...init,
    credentials: "include",
  });

  if (res.status === 401 && !isRefreshUrl(url)) {
    const refreshed = await doRefresh();
    if (refreshed) {
      res = await fetch(input, {
        ...init,
        credentials: "include",
      });
    } else {
      sessionExpiredHandler?.();
      throw new Error("Session expired");
    }
  }

  return res;
}

// PUBLIC ROUTES
export async function signup(dto: SignupRequestDto): Promise<UserView | null> {
  const res = await fetch(`${API_BASE}/api/auth/signup`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
    credentials: "include",
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to sign up");
  }

  return res.json();
}

export async function signin(dto: LoginRequestDto): Promise<UserView | null> {
  const res = await fetch(`${API_BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
    credentials: "include",
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to sign up");
  }

  return res.json();
}

export async function logout() {
  const res = await fetch(`${API_BASE}/api/auth/logout`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to sign up");
  }

  return res.json();
}

// PROTECTED ROUTES
export async function fetchMe(): Promise<UserView | null> {
  const res = await fetchWithAuth(`${API_BASE}/api/auth/me`, {
    credentials: "include",
  });

  if (res.status === 401) return null;
  if (!res.ok) throw new Error("Failed to fetch user");

  return res.json();
}

export async function fetchProjects(
  query: GetProjectsQueryDto,
): Promise<PaginatedProjectsListView> {
  const params = new URLSearchParams();
  params.set("page", String(query.page));
  params.set("pageSize", String(query.pageSize));
  if (query.includeArchived !== undefined)
    params.set("includeArchived", String(query.includeArchived));
  if (query.search) params.set("search", query.search);
  if (query.filter) params.set("filter", query.filter);
  if (query.sort) params.set("sort", query.sort);

  const res = await fetchWithAuth(
    `${API_BASE}/api/projects?${params.toString()}`,
    { credentials: "include" },
  );
  if (!res.ok) throw new Error("Failed to fetch projects");
  return res.json();
}

export async function createProject(
  dto: CreateProjectDto,
): Promise<ProjectView> {
  const res = await fetchWithAuth(`${API_BASE}/api/projects`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to create project");
  }
  return res.json();
}

export async function fetchProject(id: string): Promise<ProjectDetailView> {
  const res = await fetchWithAuth(`${API_BASE}/api/projects/${id}`, {
    credentials: "include",
  });
  if (!res.ok) {
    if (res.status === 404) throw new Error("Project not found");
    throw new Error("Failed to fetch project");
  }
  return res.json();
}

export async function createTask(
  projectId: string,
  dto: CreateTaskDto,
): Promise<TaskView> {
  const res = await fetchWithAuth(`${API_BASE}/api/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...dto, projectId }),
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to create task");
  }
  return res.json();
}

export async function fetchTasks(
  query: FindTasksQuery,
): Promise<PaginationResult<TaskView>> {
  const params = new URLSearchParams();
  params.set("projectId", query.projectId);
  params.set("page", String(query.page ?? 1));
  params.set("limit", String(query.limit ?? 20));
  if (query.status) params.set("status", query.status);
  if (query.assigneeId) params.set("assigneeId", query.assigneeId);
  if (query.search?.trim()) params.set("search", query.search.trim());

  const res = await fetchWithAuth(
    `${API_BASE}/api/tasks?${params.toString()}`,
    { credentials: "include" },
  );

  if (!res.ok) throw new Error("Failed to fetch tasks");
  return res.json();
}

export async function fetchTask(taskId: string): Promise<TaskView> {
  const res = await fetchWithAuth(`${API_BASE}/api/tasks/${taskId}`, {
    credentials: "include",
  });
  if (!res.ok) {
    if (res.status === 404) throw new Error("Task not found");
    throw new Error("Failed to fetch task.");
  }
  return res.json();
}

export async function updateProject(
  id: string,
  dto: UpdateProjectDto,
): Promise<ProjectView> {
  const res = await fetchWithAuth(`${API_BASE}/api/projects/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to update project");
  }
  return res.json();
}

export async function archiveProject(id: string): Promise<ProjectView> {
  const res = await fetchWithAuth(`${API_BASE}/api/projects/${id}/archive`, {
    method: "PATCH",
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to archive project");
  }
  return res.json();
}

export async function unarchiveProject(id: string): Promise<ProjectView> {
  const res = await fetchWithAuth(`${API_BASE}/api/projects/${id}/unarchive`, {
    method: "PATCH",
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to unarchive project");
  }
  return res.json();
}

export async function fetchProjectMembers(
  projectId: string,
): Promise<ProjectMembersView> {
  const res = await fetchWithAuth(
    `${API_BASE}/api/projects/${projectId}/members`,
    { credentials: "include" },
  );
  if (!res.ok) throw new Error("Failed to fetch project members");
  return res.json();
}

export async function addProjectMember(
  projectId: string,
  dto: AddProjectMemberDto,
): Promise<ProjectMemberView> {
  const res = await fetchWithAuth(
    `${API_BASE}/api/projects/${projectId}/members`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dto),
      credentials: "include",
    },
  );
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to add member");
  }
  return res.json();
}

export async function updateProjectMemberRole(
  projectId: string,
  userId: string,
  dto: UpdateProjectMemberRoleDto,
): Promise<ProjectMemberView> {
  const res = await fetchWithAuth(
    `${API_BASE}/api/projects/${projectId}/members/${userId}`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dto),
      credentials: "include",
    },
  );
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to update role");
  }
  return res.json();
}

export async function removeProjectMember(
  projectId: string,
  userId: string,
): Promise<void> {
  const res = await fetchWithAuth(
    `${API_BASE}/api/projects/${projectId}/members/${userId}`,
    { method: "DELETE", credentials: "include" },
  );
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to remove member");
  }
}

export async function fetchUsers(search?: string): Promise<UserView[]> {
  const url = search?.trim()
    ? `${API_BASE}/api/users?search=${encodeURIComponent(search.trim())}`
    : `${API_BASE}/api/users`;
  const res = await fetchWithAuth(url, { credentials: "include" });
  if (!res.ok) throw new Error("Failed to fetch users");
  return res.json();
}

export async function deleteTask(taskId: string): Promise<void> {
  const res = await fetchWithAuth(`${API_BASE}/api/tasks/${taskId}`, {
    method: "DELETE",
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({}));
    throw new Error(error.message ?? "Failed to delete task");
  }
}

export async function updateTask(
  projectId: string,
  taskId: string,
  payload: CreateTaskDto,
): Promise<TaskView> {
  const response = await fetch(`/api/projects/${projectId}/tasks/${taskId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => null);
    throw new Error(error?.message ?? "Failed to update task");
  }

  return response.json();
}
